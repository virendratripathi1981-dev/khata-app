/*
  WhatsApp Attendance Bridge
  - Receives Meta WhatsApp Cloud API webhook events.
  - Accepts messages: IN / PRESENT / CHECKIN and OUT / CHECKOUT.
  - Maps the sender WhatsApp number to an employee.
  - Writes Check-In/Check-Out into Supabase timelog.
  - Daily attendance remains derived from the Time Log in the web app.

  Required environment variables:
    WHATSAPP_VERIFY_TOKEN
    WHATSAPP_ACCESS_TOKEN
    WHATSAPP_PHONE_NUMBER_ID
    SUPABASE_URL
    SUPABASE_SERVICE_ROLE_KEY
    PORT (optional, default 3000)
*/
const express = require("express");
const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN;
const ACCESS_TOKEN = process.env.WHATSAPP_ACCESS_TOKEN;
const PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_NUMBER_ID;
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

function requireConfig() {
  const missing = [];
  for (const [k,v] of Object.entries({
    WHATSAPP_VERIFY_TOKEN: VERIFY_TOKEN,
    WHATSAPP_ACCESS_TOKEN: ACCESS_TOKEN,
    WHATSAPP_PHONE_NUMBER_ID: PHONE_NUMBER_ID,
    SUPABASE_URL,
    SUPABASE_SERVICE_ROLE_KEY
  })) if (!v) missing.push(k);
  if (missing.length) throw new Error("Missing configuration: " + missing.join(", "));
}

function todayIST() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric", month: "2-digit", day: "2-digit"
  }).format(new Date());
}

function timeIST() {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit", minute: "2-digit", hour12: false
  }).format(new Date());
}

async function sb(path, options={}) {
  requireConfig();
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    ...options,
    headers: {
      "apikey": SUPABASE_SERVICE_ROLE_KEY,
      "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      "Content-Type": "application/json",
      "Prefer": "return=representation",
      ...(options.headers || {})
    }
  });
  const body = await r.text();
  if (!r.ok) throw new Error(`Supabase ${r.status}: ${body}`);
  return body ? JSON.parse(body) : null;
}

async function findEmployeeByWhatsApp(phone) {
  // Recommended: add whatsapp_phone to your employees JSON records.
  // This fallback also checks common phone/mobile field names.
  const rows = await sb("khata_data?key=eq.employees&select=value");
  const employees = rows?.[0]?.value || [];
  const normalized = String(phone).replace(/\D/g, "").replace(/^91/, "");
  return employees.find(e => {
    const p = String(e.whatsapp_phone || e.whatsapp || e.mobile || e.phone || "")
      .replace(/\D/g, "").replace(/^91/, "");
    return p && p === normalized;
  }) || null;
}

async function getTimeLog(empId, date) {
  const rows = await sb(`khata_data?key=eq.timelog&select=value`);
  const timelog = rows?.[0]?.value || [];
  return timelog.find(x => x.empId === empId && x.date === date) || null;
}

async function saveTimeLog(empId, date, action) {
  const rows = await sb(`khata_data?key=eq.timelog&select=value`);
  const timelog = rows?.[0]?.value || [];
  let rec = timelog.find(x => x.empId === empId && x.date === date);

  if (!rec) {
    rec = { id: "wa-" + Date.now(), date, empId, checkIn: "", checkOut: "", approval: "", source: "WhatsApp" };
    timelog.push(rec);
  }

  if (action === "IN") rec.checkIn = timeIST();
  if (action === "OUT") rec.checkOut = timeIST();
  rec.updatedAt = new Date().toISOString();
  rec.source = "WhatsApp";

  await sb("khata_data?key=eq.timelog", {
    method: "PATCH",
    body: JSON.stringify({value: timelog})
  });
  return rec;
}

async function sendWhatsAppText(to, body) {
  requireConfig();
  const r = await fetch(`https://graph.facebook.com/v23.0/${PHONE_NUMBER_ID}/messages`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${ACCESS_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to,
      type: "text",
      text: { body }
    })
  });
  if (!r.ok) throw new Error(`WhatsApp send ${r.status}: ${await r.text()}`);
}

app.get("/webhook", (req,res) => {
  if (req.query["hub.mode"] === "subscribe" &&
      req.query["hub.verify_token"] === VERIFY_TOKEN) {
    return res.status(200).send(req.query["hub.challenge"]);
  }
  return res.sendStatus(403);
});

app.post("/webhook", async (req,res) => {
  // Acknowledge immediately; process after.
  res.sendStatus(200);
  try {
    const changes = req.body?.entry?.flatMap(e => e.changes || []) || [];
    for (const change of changes) {
      const value = change.value || {};
      const messages = value.messages || [];
      for (const msg of messages) {
        if (msg.type !== "text") continue;
        const from = msg.from;
        const command = String(msg.text?.body || "").trim().toUpperCase();
        let action = null;
        if (/^(IN|PRESENT|CHECKIN|CHECK-IN)$/.test(command)) action = "IN";
        if (/^(OUT|CHECKOUT|CHECK-OUT)$/.test(command)) action = "OUT";
        if (!action) {
          await sendWhatsAppText(from, "Attendance: IN = Check-In, OUT = Check-Out.");
          continue;
        }

        const emp = await findEmployeeByWhatsApp(from);
        if (!emp) {
          await sendWhatsAppText(from, "Your WhatsApp number is not linked to an employee. Please contact Admin.");
          continue;
        }

        const date = todayIST();
        const rec = await saveTimeLog(emp.id, date, action);
        await sendWhatsAppText(
          from,
          action === "IN"
            ? `Attendance marked: Check-In ${rec.checkIn} on ${date}.`
            : `Attendance updated: Check-Out ${rec.checkOut} on ${date}.`
        );
      }
    }
  } catch (err) {
    console.error(err);
  }
});

app.get("/health", (_req,res) => res.json({ok:true, service:"whatsapp-attendance"}));
app.listen(PORT, () => console.log(`WhatsApp attendance bridge listening on :${PORT}`));
